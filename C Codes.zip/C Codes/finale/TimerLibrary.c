#include <pic18.h>


void InitTimer(){

 TRISC = TRISC | 0xC0;   // RC6 and RC7 used for serial port
   TXIE = 0;
   RCIE = 1;
   BRGH = 0;
   BRG16 = 1;
   SYNC = 0;
   SPBRG = 255;
   TXSTA = 0x22;
   RCSTA = 0x90;
   PEIE = 1;


// set up Timer2 for 1ms
   T2CON =0xC3;  
   PR2 = 249;
   TMR2ON = 1;
   TMR2IE = 1;
   TMR2IP = 1;
   PEIE = 1;



// set timer3 for
	TMR3CS=0;
  T3CON = 0x81;     //4D = 76 Hz
   TMR3ON = 1;
   TMR3IE = 1;
   TMR3IP = 1;
   PEIE = 1;


// set timer0 for
   T0CS = 0;
   T0CON = 0x81;     //76 Hz  // 0x87 = 8 Hz 0x88 = 76 Hz      0x90 = 38 Hz   0x40= 9.8 khz 
//	PR0=100;				  // 0x4D = 24 kHz  0x0A= 76.3 hz
   TMR0ON = 1;
   TMR0IE = 1;
   TMR0IP = 1;
   PEIE = 1;

// set timer1 for
	TMR1CS=0;
  T1CON = 0x81;     //4D = 76 Hz
   //PR2 = 100;
   TMR1ON = 1;
   TMR1IE = 1;
   TMR1IP = 1;
   PEIE = 1;


//Timer 1 capture
// set up Capture1 for rising edges
 TRISC2 = 1;
 CCP1CON = 0x05;
 CCP1IE = 1;
 PEIE = 1;


// turn on all interrupts
GIE = 1;
}
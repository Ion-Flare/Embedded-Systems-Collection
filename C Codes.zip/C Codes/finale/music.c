/*Ian H*/ 
#include<pic18.h>
#include <Math.h>
#include   "LCD_PortD.c"

unsigned int instrument=0,i;
unsigned long int note;


void Trumb(float vibrate){   //trumbone
vibrate=(1/vibrate)*1000;
RE0=1; RE1=0; Wait_ms(vibrate);
RE0=0; RE1=1; Wait_ms(vibrate+vibrate/2);

RE0=0; RE1=0; Wait_ms(vibrate/20);
RE0=1; RE1=0; Wait_ms(vibrate/40);
RE0=0; RE1=1; Wait_ms(vibrate/60);
RE0=1; RE1=0; Wait_ms(vibrate/40);
RE0=0; RE1=1; Wait_ms(vibrate/60);
RE0=0; RE1=0; Wait_ms(vibrate/80);
RE0=1; RE1=0; Wait_ms(vibrate/80);
RE0=0; RE1=0; Wait_ms(vibrate/135);
RE0=0; RE1=1; Wait_ms(vibrate/250);
RE0=0; RE1=0; Wait_ms(vibrate/500);
}

void Guitar (float vibrate){
vibrate=(1/(2.22*vibrate+1000))*10000;
RE0=1; RE1=0; Wait_ms(vibrate);
RE0=0; RE1=0; Wait_ms(vibrate/100);
RE0=0; RE1=1; Wait_ms(vibrate);

RE0=0; RE1=0; Wait_ms(vibrate/200);
RE0=1; RE1=0; Wait_ms(vibrate/100);
RE0=0; RE1=0; Wait_ms(vibrate/200);
RE0=0; RE1=1; Wait_ms(vibrate/100);
}


void main(){
TRISB=0xFF;
TRISC=0;
TRISD=0;
TRISE=0;



while(1){

if(RB6==1){
for(int j=0;j<2;j++){
for (i=0;i<50;i++){
note=2000; Guitar(note);
} 
Wait_ms(100);
for (i=0;i<50;i++){
note=2000; Guitar(note);
} 
Wait_ms(100);

for (i=0;i<50;i++){
note=1200; Guitar(note);
} 
Wait_ms(100);
for (i=0;i<50;i++){
note=1200; Guitar(note);
} 
Wait_ms(100);

for (i=0;i<50;i++){
note=900; Guitar(note);
} 
Wait_ms(100);
for (i=0;i<50;i++){
note=900; Guitar(note);
} 
Wait_ms(100);

for (i=0;i<50;i++){
note=1200; Guitar(note);
} 
Wait_ms(100);
for (i=0;i<50;i++){
note=1200; Guitar(note);
} 
Wait_ms(100);
}

for(int j=0;j<2;j++){
for (i=0;i<30;i++){
note=2000; Trumb(note);
} 
Wait_ms(100);
for (i=0;i<30;i++){
note=2000; Trumb(note);
} 
Wait_ms(100);

for (i=0;i<30;i++){
note=1200; Trumb(note);
} 
Wait_ms(100);
for (i=0;i<30;i++){
note=1200; Trumb(note);
} 
Wait_ms(100);

for (i=0;i<30;i++){
note=900; Trumb(note);
} 
Wait_ms(100);
for (i=0;i<30;i++){
note=900; Trumb(note);
} 
Wait_ms(100);

for (i=0;i<30;i++){
note=1200; Trumb(note);
} 
Wait_ms(100);
for (i=0;i<30;i++){
note=1200; Trumb(note);
} 
Wait_ms(100);
}
}

if (RB7==1){
instrument++;
if (instrument==2) instrument=0;
}


if(RB0==1){   //RC0 is positive and Rc1 is negative
note=320;
if (instrument==0) Guitar(note);
if (instrument==1) Trumb(note);
}

if(RB1==1){   //RC0 is positive and Rc1 is negative
note=380;
if (instrument==0) Guitar(note);
if (instrument==1) Trumb(note);
}

if(RB2==1){   //RC0 is positive and Rc1 is negative
note=550;
if (instrument==0) Guitar(note);
if (instrument==1) Trumb(note);
}

if(RB3==1){   //RC0 is positive and Rc1 is negative
note=900;
if (instrument==0) Guitar(note);
if (instrument==1) Trumb(note);
}

if(RB4==1){   //RC0 is positive and Rc1 is negative
note=1200;
if (instrument==0) Guitar(note);
if (instrument==1) Trumb(note);;
}

if(RB5==1){   //RC0 is positive and Rc1 is negative
note=2000;
if (instrument==0) Guitar(note);
if (instrument==1) Trumb(note);
}

}
}





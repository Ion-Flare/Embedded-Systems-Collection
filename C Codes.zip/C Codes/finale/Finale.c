/*Ian Hudis*/


#include<pic18.h>
#include <math.h>

#include "lcd_portd.c"  // stole from Glower
#include "TimerLibrary.c"    // all interrupts initialized in here
#include "Megalovania.c"  //neopixal and servo motor


// Global Variables
unsigned char i,temp,stab=0,alter=0;

unsigned long int TIME, TIME0, TIME1, dT;
const unsigned char Nano_S[4]="sec";
const unsigned char Mill[4]= " cm";
const unsigned char Inch[4]= " in";


unsigned char Stabalize[20]="Stabalizing   ";
unsigned char Stabal[20]=   "Stabalized    ";
unsigned char Moving[20]=   "Moving        ";
unsigned char Clear[20]=    "              ";

bank1 unsigned char MSG[20]; // the data coming in
bank1 unsigned char MSG_LENGTH; // message length
bank1 unsigned char MSG_FLAG; // set when <cr> seen

unsigned int minrange, maxrange;

int PA=0, PB=0;  // ballance
int cm; int in;

unsigned int degree=0;

unsigned int X;
unsigned int Motor_L;
unsigned int Motor_R;
unsigned int Motor2_L;
unsigned int Motor2_R;


unsigned int serv=0;
//servo
void Spin(unsigned int servo){
int a, j;
if (servo==1){
	 	RA1=1;
		for (a=0; a<3; a++)
      	for (j=0; j<617; j++);
	    RA1=0;	
		for (a=0; a<17; a++)
      	for (j=0; j<617; j++);
} else if (servo==2){
	RA1=1;
		for (a=0; a<1; a++)
      	for (j=0; j<617; j++);
	    RA1=0;	
		for (a=0; a<19; a++)
      	for (j=0; j<617; j++);
} else {
servo=0;
}
}




// Interrupt Service Routine
void interrupt IntServe(void) @ 0x10 {


// Int interrupts
 if (INT0IF) {    //active whenever RB0=1
 PA=!PA;                                                   
 INT0IF = 0; 
 }

 if (INT1IF) {
PB=0;
if (PA==1) PB=1;												
 INT1IF = 0;
 }


//timer 0
 if (TMR0IF) {    // trig pin
 RC0 = !RC0;                                
 TMR0IF = 0;
 }

// timer 1
 if (TMR1IF) {													
TIME = TIME + 0x10000;
//  1 count = 1/10 mm
 cm = (dT * 0.1715)-0.5;  
in = cm/(2.25);
if (in>20){ maxrange=1;}else{ maxrange=0;}
if (in<10) {minrange=1;} else {minrange=0;}

 TMR1IF = 0;
 }
//timer 1 capture
 if (CCP1IF) {
 if (CCP1CON == 0x05) { // rising edge 
 TIME0 = TIME + CCPR1;
 CCP1CON = 0x04;          // Cp2 is echo pin
 }
 else {
 TIME1 = TIME + CCPR1;
 dT = TIME1 - TIME0;
 CCP1CON = 0x05;
 }
 CCP1IF = 0;
 }

//timer 2
if (TMR2IF){   //servo motor

if(stab==1){

if(serv==90){ 
 if (degree<89){   //90 degrees 
for(i=degree;i<90;i++){ Spin(2); degree++;}
} else if (degree>91){
for(i=degree;i>90;i--){ Spin(1); degree--;}
}else{
Spin(0);
serv=0;
}
}


}


if(alter==1){
//finds a angle at 90 degrees

if (temp=='1' && degree>1){   //90 degrees 
for(i=degree;i>1;i--){ Spin(1); degree--;}
} else {Spin(0);}


//if (temp=='9')serv=90;

if(temp=='9'){ 
 if (degree<89){   //90 degrees 
for(i=degree;i<90;i++){ Spin(2); degree++;}
} else if (temp=='9' && degree>91){
for(i=degree;i>90;i--){ Spin(1); degree--;}
}else{
Spin(0);
}
}

if (temp=='5'){
if(degree<44){   //45 degrees
for(i=degree;i<45;i++) { Spin(2); degree++;}
}
if (degree>46){
for(i=degree;i>45;i--) { Spin(1); degree--;}
}else{
Spin(0);
}
}

if (temp=='0' && degree<180){   //90 degrees 
for(i=degree;i<180;i++){ Spin(2); degree++;}
} else{
Spin(0);
}


}
																	
TMR2IF=0;
}

//timer 3
if (TMR3IF){    //sound 1 cm = 10 hz
/*
if (stab==1){

}
*/
if (alter==1){
if (temp=='q'){
//X=1;
Motor_L=1;
}else{
//X=0;
Motor_L=0;
}
if (temp=='w'){
Motor_R=1;
//X=1;
}else{
//X=0;
Motor_R=0;
}
if (temp=='e'){
//X=1;
Motor2_L=1;
}else{
//X=0;
Motor2_L=0;
}
if (temp=='r'){
Motor2_R=1;
//X=1;
}else{
//X=0;
Motor2_R=0;
}
}																	
TMR3IF=0;
}


//serial
if (RCIF) {
temp = RCREG;
while (!TRMT); TXREG = temp;

if (temp=='s'||temp=='S'){
stab=1;
alter=0;
} else{ 
stab=0;
}

if (temp=='a'||temp=='A'){
alter++;
if (alter==2){
alter=0;
}
}

 if (temp > 20) MSG[MSG_LENGTH++] = temp;
 if (MSG_LENGTH > 7) {
LCD_Inst(1);  // clear LCD
LCD_Move(1,9);
MSG_LENGTH = 0;
}

 if (temp == 13) MSG_FLAG = 1;

}RCIF = 0;
}




void main(void){


TRISA=0;
TRISB=0xFF;
 TRISC = 0x04; //captures every rising edge
 TRISD = 0;
 ADCON1 = 0x0F;



LCD_Init();
Wait_ms(200) ;
LCD_Inst(1);  // clear LCD
Wait_ms(100);


TIME=0;

InitTimer();  //initializes all interrupts

Spin(1);  // goes to zero
Wait_ms(1000);
Spin(0);


while(1){

LCD_Move(1,9); for(i=0;i<20;i++) LCD_Write(MSG[i]);




//LCD_Move(0,0); LCD_Out(dT, 7);
LCD_Move(1,0); LCD_Out(in,2); 
LCD_Move(1,4); for (i=0; i<3; i++) LCD_Write(Inch[i]);
if (stab==1 && in<800){
Motor_L=1;
} else if (stab==1 && in>2000){
Motor_R=1;
}else{
Motor_L=0;
}


if(alter==0 && stab == 0){
GridFlare(10,0,30,0); 
LCD_Move(0,0);  for(i=0;i<20;i++) LCD_Write(Clear[i]);
}
if (stab==1 && PA==1 && PB==1 && in<800){
 stab=0;
GridFlare(10,0,30,0); 
Motor_L=0; Motor_R=0; Motor2_L=0; Motor2_R=0;
LCD_Move(0,0);  for(i=0;i<20;i++) LCD_Write(Stabal[i]);
Wait_ms(500);
} 


if (alter==1){
GridFlare(0,40,40,0); 
LCD_Move(0,0);  for(i=0;i<20;i++) LCD_Write(Moving[i]);

 LCD_Move(0,13); 


LCD_Out2(degree,0);

}

if (stab==1){                                                  
GridFlare(0,80,0,0);
LCD_Move(0,0);  for(i=0;i<20;i++) LCD_Write(Stabalize[i]);
serv=90;  //servo motor

if (PB==1){  LCD_Move(0,12); LCD_Write('@'); }  // balance
if (PA==1){  LCD_Move(0,13); LCD_Write('@'); }
if (PB==0 || PB ==0) {
Motor2_L=1; Motor2_R=0;
Wait_ms(500);
Motor2_L=0; Motor2_R=1;
Wait_ms(500);
}else{
Motor2_L=0; Motor2_R=0;
}

}



//AurFlare(X);

if (Motor_L==1){
RA2=0; RA3=1;
Wait_ms(50);
RA2=0; RA3=0;
}
if (Motor_R==1){
RA2=1; RA3=0;
Wait_ms(50);
RA2=0; RA3=0;
}
if (Motor2_L==1){
RC3=0; RC4=1;
Wait_ms(50);
RC3=0; RC4=0;
}
if (Motor2_R==1){
RC3=1; RC4=0;
Wait_ms(50);
RC3=0; RC4=0;
}

}
}
 
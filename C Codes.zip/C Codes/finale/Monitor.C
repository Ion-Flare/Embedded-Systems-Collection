// Global Variables
// Subroutine Declarations
#include <pic18.h>
#include <stdio.h>
// Subroutines
#include "function.c"
#include "sci_init.c" // see above
#include "a2d.c"
// main
{
 SCI_Init();
 while(1) {
// read the A/D input. Data = 0..1023
 Data = A2D_Read(0);
// Send Data to the PC via the SCI port in hexadecimal format.
 while(!TRMT); TXREG = ascii(Data >> 12);
 while(!TRMT); TXREG = ascii(Data >> 8);
 while(!TRMT); TXREG = ascii(Data >> 4);
 while(!TRMT); TXREG = ascii(Data);
// end with a carriage return <13>, line feed <10>
 while(!TRMT); TXREG = 13;
 while(!TRMT); TXREG = 10;
// and repeat every second.
 Wait_ms(1000);
 }
 }
/* Ian Hudis */

//libraries
#include <stdio.h>
#include <pic18.h>
#include <math.h>

//subroutines
#include "lcd_portd.c"
#include "TimerLibrary.c"

// Global Variables
unsigned long int TIME, TIME0, TIME1, dT,i;
unsigned int active=0,T3,type;

const unsigned char Nano_S[3]="sec";
const unsigned char Mill[3]= " cm";
const unsigned char Inch[3]= " in";


void interrupt IntServe(void){
 if (TMR0IF) {    // trig pin
 RC0 = !RC0;
 TMR0IF = 0;
 }
 if (TMR1IF) {
 TIME = TIME + 0x10000;
 TMR1IF = 0;
 }
 if (CCP1IF) {
 if (CCP1CON == 0x05) { // rising edge 
 TIME0 = TIME + CCPR1;
 CCP1CON = 0x04;          // Cp2 is echo pin
 }
 else {
 TIME1 = TIME + CCPR1;
 dT = TIME1 - TIME0;
 CCP1CON = 0x05;
 }
 CCP1IF = 0;
 }

if (TMR3IF){    //sound 1 cm = 10 hz
if(active==1){
T3=(10000000/(2*(type+22)))-50; // converts frequency to clocks
TMR3=-T3;
RA1=!RA1;
RA2=!RA2;
}
TMR3IF=0;
}

}

void main(){
int cm;
int in;
 TRISA = 0;
 TRISB = 0xFF;
 TRISC = 0x04; //captures every rising edge
 TRISD = 0;
 ADCON1 = 0x0F;
LCD_Init();
  Wait_ms(500   )  ;
LCD_Inst(1);  // clear LCD
 Wait_ms(100);
 TIME = 0;

InitTimer();  //from library

LCD_Move(0,12);  for (i=0; i<3; i++) LCD_Write(Nano_S[i]);
LCD_Move(1,5);  for (i=0; i<3; i++) LCD_Write(Mill[i]);
LCD_Move(1,14); for (i=0; i<3; i++) LCD_Write(Inch[i]);

while(1){
//  1 count = 1/10 mm
 cm = dT * 0.1715;  
in = cm/(2.54);
 LCD_Move(0,0); LCD_Out(dT, 7);
 LCD_Move(1,0); LCD_Out2(cm, 2);
LCD_Move(1,9); LCD_Out2(in, 2);
type=cm+110;
if(RB0==1) {active=1;}else{active=0;}	
}
}


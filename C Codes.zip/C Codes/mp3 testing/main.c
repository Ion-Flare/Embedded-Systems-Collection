/* Ion Hudis */

//libraries
#include <stdio.h>
#include <pic18.h>



// Subroutines
#include        "lcd_portd.c"

unsigned char i;

/*
#define byte __uint8_t  //byte is not a normal c command
#define word __uint16_t //makes 16 bit word
#define dword __uint32_t //32 bit word
*/
const unsigned char Mill[4]= "MP3";


# define Start_Byte 0x7E
# define Version_Byte 0xFF
# define Command_Length 0x06
# define End_Byte 0XEF
# define Acknowledge 0x00 //returns info with command 0x41 [0x01:info] [0x00:no info]   

# define Acitvated 0 
unsigned char Command_line[10];

//int next_Track = RB1;
//const int pause_Track = RB0;
//const int previous_Track= RB3;  

int isPlaying=0;

void execute_CMD(unsigned char CMD,unsigned char Par1,unsigned char Par2);
void pause();
void play();
void playNext();
void playPrevious();
void setVolume(int volume);
void playFirst();

void main(void)
{
  
// Initialize the A/D port
   TRISA = 0;
   TRISB = 0xFF;
   TRISC = 0;
   TRISD = 0;
   TRISE = 0;
   TRISA = 0;
   ADCON1 = 15;




   LCD_Init();                  // initialize the LCD
 Wait_ms(200);
LCD_Inst(1);  // clear LCD




   i = 0;

 Wait_ms(200);



playFirst();

   while(1) {
LCD_Move(0,5);  for (i=0; i<3; i++) LCD_Write(Mill[i]);




if(RB0==1){   //this is the pause button
	if (isPlaying==1){
  	pause();
	isPlaying=0;
	}else{
	isPlaying=1;
	play();
	}
} //RB0


if(RB1==1){   //this is the pause button

	if (isPlaying==1)	playNext();

} //RB1

if (RB3==1){

	if (isPlaying==1)	playPrevious();

}//RB3

   

}//while
}//void main





void pause(){
execute_CMD(0x0D,0,1);
Wait_ms(500);
}

void play(){
execute_CMD(0x0D,0,1);
Wait_ms(500);
}

void playNext(){
execute_CMD(0x01,0,1);
Wait_ms(500);
}

void playPrevious(){
execute_CMD(0x02,0,1);
Wait_ms(500);
}

void setVolume(int volume){
execute_CMD(0x06,0,volume);
Wait_ms(2000);
}

void playFirst(){
execute_CMD(0x0D,0,1);
Wait_ms(500);
setVolume(20);
Wait_ms(500);
execute_CMD(0x0E,0,1);
Wait_ms(500);
}

void execute_CMD(unsigned char CMD,unsigned char Par1,unsigned char Par2){ //execute command and parameters
//calc the checksum (2 bytes) ->16 bit
int checksum= -(Version_Byte+Command_Length+CMD+Acknowledge +Par1+Par2); 
//find msb and lsb
unsigned char lowbyte = checksum & 0xff;
unsigned char highbyte = checksum >> 8;
//build
unsigned char Command_line[10] = {Start_Byte,Version_Byte,Command_Length};  // commandline[bits 0 to 2]
Command_line[3]=CMD; 
Command_line[4]=Acknowledge;
Command_line[5]=Par1;
Command_line[6]=Par2;
Command_line[7]=highbyte;
Command_line[8]=lowbyte;
Command_line[9]=End_Byte;


LCD_Move(1,4); for (i=0; i<10; i++) LCD_Write(Command_line[i]);

//send command line to the module
RC1=0;   
for(unsigned char k=0; k<10; k++){    //makes Rc0 and Rc1 act as a serial port
RC0=Command_line[k];
RC1=1;  //1  rising edge
Wait_ms(50);
RC1=0; //0
Wait_ms(50);
}


} //void execute
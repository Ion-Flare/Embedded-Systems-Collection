/*Ian Hudis */
// NeoPixel data out = RD1
unsigned char PIXEL @ 0x000;

#include <pic18.h>




void NeoPixel_Display(unsigned char RED, 
		unsigned char GREEN, unsigned char BLUE)
{
   PIXEL = GREEN;	asm("  call Pixel_8 ");
   PIXEL = RED;		asm("  call Pixel_8 ");
   PIXEL = BLUE;	asm("  call Pixel_8 ");

   asm("    return");


#asm
PIXEL EQU 0


Pixel_8:
    call	Pixel_1
    call	Pixel_1
    call	Pixel_1
    call	Pixel_1
    call	Pixel_1
    call	Pixel_1
    call	Pixel_1
    call	Pixel_1
    return

Pixel_1:
/*
	#endasm
	RA1=0;
	#asm
    nop
	btfss	PIXEL,7
	#endasm
	RA1=1;
	#asm
 	rlncf   PIXEL,F
	nop
    nop
   #endasm
	RA1=1;
	#asm
	return
#endasm
*/

	bsf		((c:3971)),1	; PORTD,0
    nop
	btfss   ((c:0000)),7
	bcf		((c:3971)),1
	rlncf   ((c:0000)),F
    nop
    nop
    bcf		((c:3971)),1
    return


#endasm


   }

void Wait(unsigned int X)
{
   unsigned int i, j;

   for (i=0; i<X; i++)
      for (j=0; j<609; j++);
   }

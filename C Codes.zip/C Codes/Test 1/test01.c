//test code 1/14/18

// Basically the clock example

#include <pic18.h>
#include <stdio.h>

// Global Variables

void Wait(unsigned int DATA)
{
   unsigned int i, j;
   for (i=0; i<DATA; i++) {
      for (j=0; j<1000; j++);
   }
}
   
// Main Routine

void main(void){
   
unsigned char SEC, MIN, HR;

   TRISA = 0;
   TRISB = 0;
   TRISC = 0;
   TRISD = 0;
   TRISE = 0;
   ADCON1 = 0x0F;
   SEC = 0;
   MIN = 0;
   HR  = 0;
   
   while(1) {
	RA4 = RD1; // copies portA 4 bit to PortD 1
      SEC = SEC + 1;
      if (SEC > 59) {
         SEC = 0;
         MIN = MIN + 1;
         }

      if (MIN > 59) {
         MIN = 0;
         HR = HR + 1;
         }
      if (HR > 12) HR = 1;

      PORTD = SEC;
      PORTC = MIN;
      PORTB = HR;

//added code


if (MIN == 1){
	RA0=1;
} else { RA0=0;
}

if (MIN == 2) {
	RA1=1;
} else { RA1=0;
}

if (MIN == 3) {
	RA2=1;
} else { RA2=0;
}

if (MIN == 4)
{
	RA3=1;
} else { RA3=0;
}


      Wait(1000);
      }
   }
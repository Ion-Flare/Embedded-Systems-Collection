/* Ian Hudis */

#include  <pic18.h>


const unsigned char RUN;

// Subroutines
#include   "lcd_portd.c" //stole from Glower
#include   "TimerLibrary.c" 


unsigned int type=220;
unsigned int T1; // converts frequency to clocks;
unsigned int play=0;

void interrupt IntServe(void) {

if (TMR1IF){  // timer 1
if (play==1){
T1=(10000000/(2*(type+22)))-50; // converts frequency to clocks
TMR1=-T1;
RC1=!RC1;
RC2=!RC2;
}
TMR1IF=0;
}

 if (INT0IF) {    //active whenever RB0=1

 INT0IF = 0;
 }
 if (INT1IF) {
type++;
 INT1IF = 0;
 }
if (INT2IF) {  
type--;
 INT2IF = 0;
 }

}

void Megalovania(){
type=136; play=1;
Wait_ms(100); play=0;  // 135 = D
Wait_ms(100);
type=136; play=1;
Wait_ms(100); play=0;  // 135 = D
Wait_ms(100);

type=311; play=1;
Wait_ms(200); play=0;  // 135 = higher D
Wait_ms(200);
type=220; play=1;
Wait_ms(250); play=0;  // 220 = A
Wait_ms(250);
type=201; play=1;
Wait_ms(200); play=0;  // 201 = A flat
Wait_ms(150);
type=194; play=1;
Wait_ms(200); play=0;  // 201 = G 
Wait_ms(150);
type=166; play=1;
Wait_ms(200); play=0;  // 201 = F
Wait_ms(150);
type=136; play=1;
Wait_ms(100); play=0;  // 135 = D
Wait_ms(100);
type=166; play=1;
Wait_ms(100); play=0;  // 201 = F
Wait_ms(100);
type=194; play=1;
Wait_ms(100); play=0;  // 201 = G 
Wait_ms(150);


type=116; play=1;
Wait_ms(100); play=0;  // 135 = C
Wait_ms(100);
type=116; play=1;
Wait_ms(100); play=0;  // 135 = C
Wait_ms(100);

type=311; play=1;
Wait_ms(200); play=0;  // 135 = higher D
Wait_ms(200);
type=220; play=1;
Wait_ms(250); play=0;  // 220 = A
Wait_ms(250);
type=201; play=1;
Wait_ms(200); play=0;  // 201 = A flat
Wait_ms(150);
type=194; play=1;
Wait_ms(200); play=0;  // 201 = G 
Wait_ms(150);
type=166; play=1;
Wait_ms(200); play=0;  // 201 = F
Wait_ms(150);
type=136; play=1;
Wait_ms(100); play=0;  // 135 = D
Wait_ms(100);
type=166; play=1;
Wait_ms(100); play=0;  // 201 = F
Wait_ms(100);
type=194; play=1;
Wait_ms(100); play=0;  // 201 = G 
Wait_ms(150);


type=108; play=1;
Wait_ms(100); play=0;  // 135 = B
Wait_ms(100);
type=108; play=1;
Wait_ms(100); play=0;  // 135 = B
Wait_ms(100);

type=311; play=1;
Wait_ms(200); play=0;  // 135 = higher D
Wait_ms(200);
type=220; play=1;
Wait_ms(250); play=0;  // 220 = A
Wait_ms(250);
type=201; play=1;
Wait_ms(200); play=0;  // 201 = A flat
Wait_ms(150);
type=194; play=1;
Wait_ms(200); play=0;  // 201 = G 
Wait_ms(150);
type=166; play=1;
Wait_ms(200); play=0;  // 201 = F
Wait_ms(150);
type=136; play=1;
Wait_ms(100); play=0;  // 135 = D
Wait_ms(100);
type=166; play=1;
Wait_ms(100); play=0;  // 201 = F
Wait_ms(100);
type=194; play=1;
Wait_ms(100); play=0;  // 201 = G 
Wait_ms(150);


type=102; play=1;
Wait_ms(100); play=0;  // 135 = B flat
Wait_ms(100);
type=102; play=1;
Wait_ms(100); play=0;  // 135 = B flat
Wait_ms(100);

type=311; play=1;
Wait_ms(200); play=0;  // 135 = higher D
Wait_ms(200);
type=220; play=1;
Wait_ms(250); play=0;  // 220 = A
Wait_ms(250);
type=201; play=1;
Wait_ms(200); play=0;  // 201 = A flat
Wait_ms(150);
type=194; play=1;
Wait_ms(200); play=0;  // 201 = G 
Wait_ms(150);
type=166; play=1;
Wait_ms(200); play=0;  // 201 = F
Wait_ms(150);
type=136; play=1;
Wait_ms(100); play=0;  // 135 = D
Wait_ms(100);
type=166; play=1;
Wait_ms(100); play=0;  // 201 = F
Wait_ms(100);
type=194; play=1;
Wait_ms(100); play=0;  // 201 = G 
Wait_ms(150);

}


void Saints(){   
//saints row
type=135; play=1;
Wait_ms(125); play=0;  // 135 = D
Wait_ms(125);
type=135; play=1;
Wait_ms(63); play=0;
Wait_ms(63);
type=135; play=1;
Wait_ms(63); play=0;
Wait_ms(63);
type=135; play=1;
Wait_ms(125); play=0;
Wait_ms(125);
type=135; play=1;
Wait_ms(63); play=0;
Wait_ms(63);
type=135; play=1;
Wait_ms(63); play=0;
Wait_ms(63);
type=135; play=1;
Wait_ms(125); play=0;
Wait_ms(125);
type=135; play=1;
Wait_ms(63); play=0;
Wait_ms(63);
type=135; play=1;
Wait_ms(63); play=0;
Wait_ms(63);
type=156; play=1;
Wait_ms(63); play=0;    //156 = E
Wait_ms(63);
type=135; play=1;
Wait_ms(63); play=0;
Wait_ms(63);
type=135; play=1;
Wait_ms(63); play=0;
Wait_ms(63);

type=166; play=1;      //166 = F
Wait_ms(125); play=0;
Wait_ms(125);
type=166; play=1;      //166 = F
Wait_ms(63); play=0;
Wait_ms(63);
type=166; play=1;      //166 = F
Wait_ms(63); play=0;
Wait_ms(63);
type=166; play=1;      //166 = F
Wait_ms(125); play=0;
Wait_ms(125);
type=166; play=1;      //166 = F
Wait_ms(63); play=0;
Wait_ms(63);
type=166; play=1;      //166 = F
Wait_ms(63); play=0;
Wait_ms(63);
type=166; play=1;      //166 = F
Wait_ms(125); play=0;
Wait_ms(125);
type=166; play=1;      //166 = F
Wait_ms(63); play=0;
Wait_ms(63);
type=166; play=1;      //166 = F
Wait_ms(63); play=0;
Wait_ms(63);
type=135; play=1;      //D
Wait_ms(63); play=0;
Wait_ms(63);
type=166; play=1;    //F  
Wait_ms(63); play=0;
Wait_ms(63);
type=220; play=1;    // 220 = A  
Wait_ms(63); play=0;
Wait_ms(63);
type=231; play=1;    // 231 = B flat
Wait_ms(63); play=0;
Wait_ms(63);


type=137; play=1;    // 137 = B flat
Wait_ms(125); play=0;
Wait_ms(125);
type=137; play=1;    // 137 = B flat
Wait_ms(63); play=0;
Wait_ms(63);
type=137; play=1;    // 137 = B flat
Wait_ms(63); play=0;
Wait_ms(63);
type=137; play=1;    // 137 = B flat
Wait_ms(125); play=0;
Wait_ms(125);
type=137; play=1;    // 137 = B flat
Wait_ms(63); play=0;
Wait_ms(125);
type=137; play=1;    // 137 = B flat
Wait_ms(63); play=0;
Wait_ms(63);
type=137; play=1;    // 137 = B flat
Wait_ms(125); play=0;
Wait_ms(125);
type=137; play=1;    // 137 = B flat
Wait_ms(63); play=0;
Wait_ms(63);
type=137; play=1;    // 137 = B flat
Wait_ms(63); play=0;
Wait_ms(63);
type=116; play=1;    // 116 = C
Wait_ms(63); play=0;
Wait_ms(63);
type=137; play=1;    // 137 = B flat
Wait_ms(63); play=0;
Wait_ms(63);
type=137; play=1;    // 137 = B flat
Wait_ms(63); play=0;
Wait_ms(63);
type=137; play=1;    // 137 = B flat
Wait_ms(63); play=0;
Wait_ms(63);

type=81; play=1;    // 81 = G
Wait_ms(125); play=0;
Wait_ms(125);
type=81; play=1;    // 81 = G
Wait_ms(63); play=0;
Wait_ms(63);
type=81; play=1;    // 81 = G
Wait_ms(63); play=0;
Wait_ms(63);
type=81; play=1;    // 81 = G
Wait_ms(125); play=0;
Wait_ms(125);
type=81; play=1;    // 81 = G
Wait_ms(63); play=0;
Wait_ms(63);
type=81; play=1;    // 81 = G
Wait_ms(63); play=0;
Wait_ms(63);

type=135; play=1;    // D
Wait_ms(63); play=0;
Wait_ms(63);
type=135; play=1;    // D
Wait_ms(63); play=0;
Wait_ms(63);
type=166; play=1;    // F
Wait_ms(63); play=0;
Wait_ms(63);
type=166; play=1;    // F
Wait_ms(63); play=0;
Wait_ms(63);
type=192; play=1;    // G
Wait_ms(63); play=0;
Wait_ms(63);
type=192; play=1;    // G
Wait_ms(63); play=0;
Wait_ms(63);
type=220; play=1;    // G
Wait_ms(63); play=0;
Wait_ms(63);
type=220; play=1;    // G
Wait_ms(63); play=0;
Wait_ms(63);

}

void main(void){

// initialize INT0 interrupts

TRISA=0;
TRISC=0;
TRISB=0xFF;

 TRISB0 = 1;
 TRISB1 = 1;
 TRISB2 = 1;
 ADCON1 = 15;

 INT0IE = 1;
 INTEDG0 = 1; // rising edges
// initialize INT1 interrupts
 INT1IE = 1;
 INT1IP = 1;
 INTEDG1 = 1; // rising edges

// initialize INT2 interrupts
 INT2IE = 1;
 INT2IP = 1;
 INTEDG2 = 0; // falling edges



//InitTimer();
// set timer1 for
	TMR1CS=0;
  T1CON = 0x81;     //4D = 76 Hz
   //PR2 = 100;
   TMR1ON = 1;
   TMR1IE = 1;
   TMR1IP = 1;
   PEIE = 1;
GIE=1;
//_____________________________________


LCD_Init();
  Wait_ms(500);
LCD_Inst(1);  // clear LCD

RC2=1;

while(1){
LCD_Move(0,0); LCD_Out(type,0);


while(RB0==1){
Saints();
}


if(RB7==1){   //dah
Megalovania();
}

if(RB6==1){   //dit
play=1;
Wait_ms(200);
play=0;
Wait_ms(200);
}

while(RB4==1) play=1;


if(RB5==1){
LCD_Init();
  Wait_ms(500   )  ;
LCD_Inst(1);  // clear LCD
}

}

}


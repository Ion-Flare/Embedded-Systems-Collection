/*  Ian Hudus */

#include <pic18.h>
// Subroutine Declarations
#include        "neopixel_A1.c"





//unsigned int Stage=0;
unsigned char Color1[3]={0,0,0};
unsigned char Color2[3]={10,0,10};  //default is off
unsigned char Color3[3]={0,5,0};

int Active=0;

void GridFlare(unsigned char R1,unsigned char G2, 
unsigned char B3,unsigned int Stage){

if (Stage==0){
Color1[0]=R1; Color1[1]=G2; Color1[2]=B3;       ///previous color 1 storage
}
if (Stage==1){
Color2[0]=R1; Color2[1]=G2; Color2[2]=B3;      // previous  color 2 storage
}
if (Stage==2){
Color3[0]=R1; Color3[1]=G2; Color3[2]=B3;       //     color 3 storage
}

//actual colors_______________

for(int i=0; i<13;i++){
NeoPixel_Display(R1,G2,B3);
} 
GIE = 1; //turns on interupts
}

void AurFlare(void){
if(RB3==1){
Active++;
}

while (Active==1){
unsigned int n;
unsigned int i;
for(n=1; n<13;n++){
for(i=0; i<n;i++)  {
NeoPixel_Display(Color1[0],Color1[1],Color1[2]);
}
Wait_ms(100);
if(RB0==1||RB1==1||RB4==1){   //interupt
Active=0;
asm("Goto Finish");
}
}
for(int n=1; n<13;n++){
for(int i=0; i<n;i++)  {
NeoPixel_Display(Color2[0],Color2[1],Color2[2]);
}
Wait_ms(100);
if(RB0==1||RB1==1||RB4==1){
Active=0;
asm("Goto Finish");
}
}
for(int n=1; n<13;n++){
for(int i=0; i<n;i++)  {
NeoPixel_Display(Color3[0],Color3[1],Color3[2]);
}
Wait_ms(100);
if(RB0==1||RB1==1||RB4==1){
Active=0;
asm("Goto Finish");
}
}

} //while()
asm(" Finish :");
} //void




void Servo(int deg){

unsigned int i;
//clockwise
if(deg<0){
deg=-deg;
for(i=0;i<deg;i++){
RA1=1;
Wait_ms(1);
RA1=0;
Wait_ms(19);
if (RB4==1||RB2==1||RB1==1||RB0==1) asm(" goto fin");
}
} else{
//counterclockwise
for(i=0;i<deg;i++){
RA1=1;
Wait_ms(2);
RA1=0;
Wait_ms(18);
if (RB4==1||RB2==1||RB1==1||RB0==1) asm(" goto fin");
}
}
asm("fin:");
}


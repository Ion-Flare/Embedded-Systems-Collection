/* Ian Hudis 3/27/18 */

#include <pic18.h>

// Subroutines
#include        "lcd_portd.c" //stole from Glower
#include         "Megalovania.c" /*constains neopixel library*/
#include        "TimerLibrary.c" 


const unsigned char RUN;
unsigned int n=0;
unsigned int T3,T2,T1,T0;


unsigned int servo=0,motor=0;    // {on/off, direction}
int TEMP,drop;

const unsigned char Goddard[21] = "Goddard            ";
const unsigned char   Clear[21] = "                   "; 
const unsigned char   Options[21]="Options            ";


// High-priority service
   unsigned int i, j,ser;


void Spin(void){
if (servo==1){
	 	RA1=1;
		for (i=0; i<3; i++)
      	for (j=0; j<617; j++);
	    RA1=0;	
		for (i=0; i<17; i++)
      	for (j=0; j<617; j++);
} else if (servo==2){
	RA1=1;
		for (i=0; i<1; i++)
      	for (j=0; j<617; j++);
	    RA1=0;	
		for (i=0; i<19; i++)
      	for (j=0; j<617; j++);
} else {
servo=0;
}

}

void knee(void){
if(motor==1){
if(T0<250||500<T0<750){
RA2=1; RA3=0;
} else{
RA2=0; RA3=1;
}
}else{
RA2=0; RA3=0;
}
}

void interrupt IntServe(void){

//timer 0
if(TMR0IF){  
if (motor==1) T0+=1;
if(T0==999) T0=0;
  TMR0IF = 0;
}

//timer 1
if(TMR1IF){  
//dc motor
if (RB2==1){   
motor++;   // 0=off, 1=counterclockwise, 2 = clockwise
if(motor==2){
motor=0;
}
}
knee();
  TMR1IF = 0;
}


   if (TMR2IF) {  //timer 2
//servo motor
if (RB5==1){
servo=1;
}else if(RB6==1){
servo=2;
}else{
servo=0;
}
Spin();

	  TMR2IF = 0;
      }
   }





void GetKey(void){

int i;
   unsigned char RESULT;
   TRISC = 0xF8;
   RESULT = 0xFF;
   PORTC = 4;
   for (i=0; i<100; i++);
   if (RC6) RESULT = 1;
   if (RC5) RESULT = 4;
   if (RC4) RESULT = 7;
   if (RC3) RESULT = 10;
   PORTC = 2;
  for (i=0; i<100; i++);
   if (RC6) RESULT = 2;
   if (RC5) RESULT = 5;
   if (RC4) RESULT = 8;
   if (RC3) RESULT = 0;
    PORTC = 1;
   for (i=0; i<100; i++);
   if (RC6) RESULT = 3;
   if (RC5) RESULT = 6;
   if (RC4) RESULT = 9;
   if (RC3) RESULT = 11;
   if (RB0) RESULT = 12;
   if (RB1) RESULT = 13;
   if (RB2) RESULT = 14;
   if (RB3) RESULT = 15;
   if (RB4) RESULT = 16;
   PORTC = 0;
  	drop=RESULT;
}
      
void ReadKey(void){
   char X, Y;
   do {
		GetKey(); 
      X =drop; 
      }   while(X > 20);
    do {
	GetKey(); 
     Y= drop;
      }   while(Y < 20); 
   Wait_ms(100);  // debounce
   TEMP=X; 
   }
 
 int Red,Blue,Green;

unsigned int Save=0;  // for saving color value      

void KeepColor(){  
//ranges from Save=0 to Save=2
////saving
if(RB7==1||RB6==1||RB5==1){
Save++;
if (Save==3){   // reset stage
Save=0;
}
LCD_Move(1,15);
if(Save==0){
//RA1=1; RA2=0; RA3=0;
LCD_Write('1');
} else if (Save==1){
//RA1=0; RA2=1; RA3=0;
LCD_Write('2');
} else { 				// Save==2
//RA1=0; RA2=0; RA3=1;
LCD_Write('3');
}

Wait_ms(200);
}
} 



// Main Routine

void main(void){
   unsigned int i, j;
   int Color, Y;
InitTimer();



	T3=0;
    T2 = 0;
	T1 =0;
	T0=0;

   LCD_Init();                  // initialize the LCD
   LCD_Move(0,0);  for (i=0; i<20; i++) LCD_Write(Goddard[i]);
   Wait_ms(1000);
   LCD_Inst(1);  // clear LCD
LCD_Move(0,0);  for (i=0; i<20; i++) LCD_Write(Options[i]);


	Color=0;
   Red = 0;
	Blue=0;
	Green=0;
   Y = 0;

   LCD_Move(1,0);  LCD_Write('R'); LCD_Write(':'); 
LCD_Move(1,8);  LCD_Write('G'); LCD_Write(':'); 
LCD_Move(0,9);  LCD_Write('B'); LCD_Write(':'); 
LCD_Move(1,15);
LCD_Write('1');



while(1){
ReadKey();
//LCD_Move(0,0);  LCD_Out(T0, 0);
if (RB1==1){
Color++;
if (Color==3){
Color=0;
}
}

//red
if (Color==0){

      if (TEMP < 10) Red = (Red*10) + TEMP;
      if (TEMP == 10) {

         Y = Red;
         Red = 0;
        }   
      if (TEMP == 11) {
         Red = -Red;
         }  
 if (Red>255){
Red=255;
}
if (RB0==1||RB4==1){   //clear
Red=0;
}
LCD_Move(1,2);  LCD_Out(Red, 0);
KeepColor();  //save color to role


}

//Blue
if (Color==1){

      if (TEMP < 10) Blue = (Blue*10) + TEMP;
      if (TEMP == 10) {

         Y = Blue;
         Blue = 0;
        }   
      if (TEMP == 11) {
         Blue = -Blue;
         }  
 if (Blue>255){
Blue=255;
}
if (RB0==1||RB4==1){   //clear
Blue=0;
}
LCD_Move(0,11);  LCD_Out(Blue, 0);

KeepColor();  //save color to role by pressing RB1 and RB3 at the same time


}

//green
if (Color==2){

      if (TEMP < 10) Green = (Green*10) + TEMP;
      if (TEMP == 10) {

         Y = Green;
         Green = 0;
        }   
      if (TEMP == 11) {
         Green = -Green;
         }  
 if (Green>255){
Green=255;
}
if (RB0==1||RB4==1){   //clear
Green=0;
}
LCD_Move(1,10);  LCD_Out(Green, 0);

KeepColor();  //save color to role


}

GridFlare(Red,Green,Blue,Save);
AurFlare();

  }

} // main void
/* Ian Hudis 3/27/18 */
#include <pic18.h>

// Global Variables
float ans;
unsigned int i;
unsigned long int TIME,fin;

// Interrupt Service Routine

void interrupt IntServe(void) 
{
   if (TMR0IF) {
      TIME = TIME + 0x10000;
      RC0 =!RC0;

      TMR0IF = 0;
      }
   }

// Subroutines
#include        "lcd_portd.c"
#include         "math.h"


// Main Routine

void main(void)
{
   float pie,cake;
   unsigned long int TIME1, TIME0;

   TRISA = 0;
   TRISB = 0xFF;
   TRISC = 0;
   TRISD = 0;
   ADCON1 = 0x0F;
 
// set up Timer0 for PS = 1
   T0CS = 0;
   T0CON = 0x88;
   TMR0ON = 1;
   TMR0IE = 1;
   TMR0IP = 1;
   PEIE = 1;

   pie = 3.14159265379;
	cake = 1.5694;
   LCD_Init();
   Wait_ms(100);

   TIME = 0;

// turn on all interrupts
   GIE = 1;
   
// Do nothing.  Interrupts do all the work.
   while(1) {

     TIME0 = TIME + TMR0;
 	if (RB0==1) Wait_ms(1000);
	if (RB1==1) ans=pie*cake;
	if(RB2==1)  ans=sqrt(cake);
	if (RB3==1){
Wait_ms(250);
while(RB3==0){
for(i=0;i<=10;i++);
}
}
	
      TIME1 = TIME + TMR0;
      LCD_Move(0,0);
	  fin=TIME1 - TIME0;
      LCD_Out100ns(fin-37, 7);         // show time
LCD_Move(1,0); LCD_Out2(1000*ans, 3);  //show answer

if(RB7==1){
fin=0;
ans=0;
}  
 
}   
   }

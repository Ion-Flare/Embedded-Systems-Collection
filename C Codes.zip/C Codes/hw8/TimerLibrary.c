#include <pic18.h>


void InitTimer(){


// set timer0 for
   T0CS = 0;
   T0CON = 0x88;     //76 Hz  // 0x87 = 8 Hz 0x88 = 76 Hz      0x90 = 38 Hz   0x40= 9.8 khz 
//	PR0=100;				  // 0x4D = 24 kHz  0x0A= 76.3 hz
   TMR0ON = 1;
   TMR0IE = 1;
   TMR0IP = 1;
   PEIE = 1;

// set timer1 for
	TMR1CS=0;
  T1CON = 0x81;     //4D = 76 Hz
   //PR2 = 100;
   TMR1ON = 1;
   TMR1IE = 1;
   TMR1IP = 1;
   PEIE = 1;

// set up Timer2 for 1ms
   T2CON =0xC3;  
   PR2 = 249;
   TMR2ON = 1;
   TMR2IE = 1;
   TMR2IP = 1;
   PEIE = 1;
// turn on all interrupts
GIE = 1;
}
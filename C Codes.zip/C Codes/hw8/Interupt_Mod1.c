#include <pic18.h>


// Global Variables


const unsigned char MSG1[21] = "1ms Interrupt       ";     
   
const unsigned char RUN;

unsigned int n=0;
unsigned int T3=16977;
unsigned int T2=19111;
unsigned int T1=20198;
unsigned int T0=22677;

// Subroutine Declarations
#include <pic18.h>

// Subroutines
#include        "lcd_portd.c"

// High-priority service
void interrupt IntServe(void)
{
   if (TMR2IF) {  //timer 2
//TMR2=-T2;
RC2 =! RC2;
  TMR2IF = 0;
      }

if(TMR1IF){  //timer 1
TMR1=-T1;
RC1=!RC1;
  TMR1IF = 0;
}

if(TMR0IF){  //timer 0
TMR0=-T0;
RC0 =! RC0;
  TMR0IF = 0;
}

if (TMR3IF){   //timer 3
TMR3=-T3;
RC3=!RC3;
TMR3IF=0;
}
   }



// Main Routine

void main(void)
{
   unsigned char i;
   unsigned int j;

   TRISA = 0;
   TRISB = 0x01;
   TRISC = 0;
   TRISD = 0;
   TRISE = 0;
   TRISA = 0;
   PORTB = 0;
   PORTC = 0;
   PORTD = 0;
   PORTE = 0;
   ADCON1 = 0x0F;



   LCD_Init();                  // initialize the LCD
   LCD_Move(0,0);  for (i=0; i<20; i++) LCD_Write(MSG1[i]);
   Wait_ms(1000);
   LCD_Inst(1);  // clear LCD


// set up Timer2 for 1ms      1111->
   T2CON =0xFF;   //204 hz //0x4D;  around 500 hz       AE
   PR2 = 74;
   TMR2ON = 1;
   TMR2IE = 1;
   TMR2IP = 1;
   PEIE = 1;


// set timer1 for
	TMR1CS=0;
  T1CON = 0x81;     
   //PR2 = 100;
   TMR1ON = 1;
   TMR1IE = 1;
   TMR1IP = 1;
   PEIE = 1;

// set timer0 for PS = 1 
   T0CS = 0;
   T0CON = 0x88;     //76 Hz  // 0x87 = 8 Hz 0x88 = 76 Hz      0x90 = 38 Hz   0x40= 9.8 khz 
//	PR0=100;				  // 0x4D = 24 kHz  0x0A= 76.3 hz
   TMR0ON = 1;
   TMR0IE = 1;
   TMR0IP = 1;
   PEIE = 1;

// set timer3 for
	TMR3CS=0;
  T3CON = 0x81; // hz   //  0x3D //10 Hz    
  // PR2 = 100;
   TMR3ON = 1;
   TMR3IE = 1;
   TMR3IP = 1;
   PEIE = 1;


// turn on all interrupts
GIE = 1;



 while(1) {
 
      }      
   }


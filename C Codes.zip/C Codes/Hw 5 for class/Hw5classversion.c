

#include <pic18.h>

#include        "lcd_portd.c"
  
 

  

void main(void){

 unsigned int i;

   TRISA = 0;
   TRISB = 0xFF;
   TRISC = 0;
   TRISD = 0;
   TRISE = 0;
   TRISA = 0;

   PORTB = 0;
   PORTC = 0;
   PORTD = 0;
   PORTE = 0;
   ADCON1 = 0x0F;

RC7=0; RC6=0; RC5=0;
while(1){
RC0=1; RC1=0;
Wait_ms(10);
RC1=0; RC0=1;
Wait_ms(10);
}

}


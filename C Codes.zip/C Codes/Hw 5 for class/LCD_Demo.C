
#include <stdio.h>

// Global Variables

const unsigned char MSG0[20] = "Why?...             ";
const unsigned char FunTimes[20] = "Stop touching me ";
const unsigned char FunTimes2[20] = "I said stop!!!  ";
const unsigned char FunTimes3[20] = "Your hurting me! ";
const unsigned char clear[20] = "                    ";

// Subroutine Declarations
#include <pic18.h>





/*LCD Stuff ____________________________________ */


// Subroutines
#include        "lcd_portd.c"
  

void Wait(unsigned int X)
{
   unsigned int i, j;

   for (i=0; i<X; i++)
      for (j=0; j<62; j++);
   }

 /*______________________________________________*/

         
void loading(){
RC0=1;
int x = 125;
Wait_ms(x);
RC0=0;		
RC1=1;
Wait_ms(x);
RC1=0;
RC2=1;
Wait_ms(x);
RC2=0;
RC3=1;
Wait_ms(x);
RC3=0;		
RC4=1;
Wait_ms(x);
RC4=0;
RC5=1;
Wait_ms(x);
RC5=0;
RC6=1;
Wait_ms(x);
RC6=0;
RC7=1;
Wait_ms(x);
RC7=0;
}



// Main Routine

void main(void){

   unsigned int HR, MIN, SEC;
   unsigned int i;

   TRISA = 0;
   TRISB = 0xFF;
   TRISC = 0;
   TRISD = 0;
   TRISE = 0;
   TRISA = 0;
   PORTB = 0;
   PORTC = 0;
   PORTD = 0;
   PORTE = 0;
   ADCON1 = 0x0F;

//______________________________________________

   LCD_Init();                  // initialize the LCD

   LCD_Move(0,0);  
for (i=0; i<20; i++) LCD_Write(MSG0[i]);  
   Wait_ms(100); 


//____________________________________	   

int active=0;  //boolean


   while(1) {

loading();

if (RB0==1 || RB1==1 || RB2==1){
active= active+1;
} else {
active=0;
}


if (active==1){
LCD_Move(1,0);

for (i=0; i<20; i++) LCD_Write(FunTimes[i]);
   i = 0;

Wait_ms(3000);

LCD_Move(1,0);
for (i=0; i<20; i++) LCD_Write(clear[i]);
i = 0;
}



if (active==2){
LCD_Move(1,0);

for (i=0; i<20; i++) LCD_Write(FunTimes2[i]);
   i = 0;

Wait_ms(3000);

LCD_Move(1,0);
for (i=0; i<20; i++) LCD_Write(clear[i]);
i = 0;
}



if (active==3){
LCD_Move(1,0);

for (i=0; i<20; i++) LCD_Write(FunTimes3[i]);
   i = 0;

Wait_ms(3000);

LCD_Move(1,0);
for (i=0; i<20; i++) LCD_Write(clear[i]);
i = 0;
}

}
}
      


   
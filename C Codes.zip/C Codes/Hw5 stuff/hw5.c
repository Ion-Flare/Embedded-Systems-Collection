
#include <stdio.h>

// Global Variables

const unsigned char MSG0[20] = "Heart Matilda   ";
const unsigned char FunTimes[20] = "Stop touching me ";
const unsigned char FunTimes2[20] = "I said stop!!!  ";
const unsigned char FunTimes3[20] = "Your hurting me! ";
const unsigned char clear[20] = "                    ";

// Subroutine Declarations
#include <pic18.h>





/*LCD Stuff ____________________________________ */


// Subroutines
#include        "lcd_portd.c"
  
 
void delay(unsigned int X)   //basically like arduino
{
   unsigned int i;
X=(X/2)*100;      //  .0625=1/1.6
   for (i=0; i<X; i++);
   }

 /*______________________________________________*/

void play(unsigned int Hz,unsigned int Period){    // plays music-> play(frequancy,time played);    
unsigned int i;
unsigned int k=(1/Hz)*100;
for (i=0;i<Period;i++){
RC0=1; RC1=0;
delay(k);
RC0=0; RC1=1;
delay(k);
}
RC0=0; RC1=0;
delay(k);
}        


// Main Routine

void main(void){


   unsigned int i;

   TRISA = 0;
   TRISB = 0xFF;
   TRISC = 0;
   TRISD = 0;
   TRISE = 0;
   TRISA = 0;
   PORTB = 0;
   PORTC = 0;
   PORTD = 0;
   PORTE = 0;
   ADCON1 = 0x0F;

//______________________________________________

   LCD_Init();                  // initialize the LCD

   LCD_Move(0,0);  
for (i=0; i<20; i++) LCD_Write(MSG0[i]);  
   Wait_ms(100); 


//____________________________________	   

int active=0;  //boolean

RA0=1; RA1=1; RA2=1;  //start off


   while(1) {



play(40,100000000);  
delay(100000000);
RA1=0; RA0=1;
play(60,100000000);
delay(100000000);
RA1=1; RA0=1;  


if (RB0==1 || RB1==1 || RB2==1){
active= active+1;
RA2=0; RA1=1; RA0=1; 
} else {
active=0;
}


if (active==1){
LCD_Move(1,0);

for (i=0; i<20; i++) LCD_Write(FunTimes[i]);
   i = 0;

Wait_ms(3000);

LCD_Move(1,0);
for (i=0; i<20; i++) LCD_Write(clear[i]);
i = 0;
}



if (active==2){
LCD_Move(1,0);

for (i=0; i<20; i++) LCD_Write(FunTimes2[i]);
   i = 0;

Wait_ms(3000);

LCD_Move(1,0);
for (i=0; i<20; i++) LCD_Write(clear[i]);
i = 0;
}



if (active==3){
LCD_Move(1,0);

for (i=0; i<20; i++) LCD_Write(FunTimes3[i]);
   i = 0;

Wait_ms(3000);

LCD_Move(1,0);
for (i=0; i<20; i++) LCD_Write(clear[i]);
i = 0;
}

}
}
      


   